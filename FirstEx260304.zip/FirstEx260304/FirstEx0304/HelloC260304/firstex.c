#include<stdio.h>

int main()
{
	int a = 7;
	printf("a=%d\n", a);
	printf("Address of a=%d \n", &a);
	printf("Address of a=%p \n", &a);
	printf("Address of a=%X \n", &a);

	return 0;
}