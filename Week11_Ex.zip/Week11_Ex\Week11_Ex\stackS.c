#include <stdio.h>
#include <stdlib.h>
#include "stackS.h"

// 공백 순차 스택을 생성하는 연산
StackType* createStack() {
	StackType* S;
	S = (StackType*)malloc(sizeof(StackType));
	S->top = -1;  // top 초깃값 설정
	return S;
}

// 순차 스택이 공백 상태인지 검사하는 연산
int isStackEmpty(StackType* S) {
	if (S->top == -1) return 1;
	else return 0;
}

// 순차 스택이 포화 상태인지 검사하는 연산
int isStackFull(StackType* S) {
	if (S->top == STACK_SIZE - 1) return 1;
	else return 0;
}

// 순차 스택의 top에 원소를 삽입하는 연산
void push(StackType* S, element item) {
	if (isStackFull(S)) return;
	else {
		S->top++;
		S->stack[S->top] = item;
	}
}

// 순차 스택의 top에서 원소를 삭제하고 반환하는 연산
element pop(StackType* S) {
	if (isStackEmpty(S)) return -1;
	else return S->stack[S->top--];
}

// 순차 스택의 top 원소를 검색하는 연산
element peekS(StackType* S) {
	if (isStackEmpty(S)) return -1;
	else return S->stack[S->top];
}

// 순차 스택의 원소를 출력하는 연산
void printS(StackType* S) {
	int i;
	printf(" Stack : [");
	for (i = 0; i <= S->top; i++)
		printf("%3d", S->stack[i]);
	printf(" ]\n");
}
