#pragma once

#define STACK_SIZE 100001

typedef int element;  // 스택 원소(element)의 자료형을 int로 정의

typedef struct {
	element stack[STACK_SIZE];  // 1차원 배열 스택 선언
	int top;
} StackType;

StackType* createStack();
int isStackEmpty(StackType* S);
int isStackFull(StackType* S);
void push(StackType* S, element item);
element pop(StackType* S);
element peekS(StackType* S);
void printS(StackType* S);
