#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "stackS.h"

int main(void)
{
	SetConsoleOutputCP(65001);  // UTF-8, CP는 Code Page의 약자
	SetConsoleCP(65001);        // 입력도 필요하면 설정

	int n, i;
	printf(" n을 입력하세요 : ");
	scanf_s("%d", &n);

	// 목표 수열 입력
	int* sequence = (int*)malloc(sizeof(int) * n);
	printf(" 수열을 입력하세요 (%d개) :\n", n);
	for (i = 0; i < n; i++)
		scanf_s("%d", &sequence[i]);

	StackType* S = createStack();

	// 연산 결과 저장 배열 (최대 push n번 + pop n번 = 2n개)
	char* ops = (char*)malloc(sizeof(char) * 2 * n);
	int opCount = 0;
	int next_push = 1;  // 다음에 push할 숫자
	int possible = 1;   // 수열 생성 가능 여부

	printf("\n ***** 스택으로 수열 만들기 ***** \n\n");

	for (i = 0; i < n; i++) {
		int target = sequence[i];

		// target에 도달할 때까지 오름차순으로 push
		while (next_push <= target) {
			push(S, next_push++);
			ops[opCount++] = '+';
		}

		// 스택 top이 target과 일치하면 pop
		if (!isStackEmpty(S) && peekS(S) == target) {
			pop(S);
			ops[opCount++] = '-';
		}
		else {
			// 이미 지나친 숫자를 요구하므로 수열 생성 불가
			possible = 0;
			break;
		}
	}

	// 결과 출력
	if (!possible) {
		printf("NO\n");
	}
	else {
		for (i = 0; i < opCount; i++)
			printf("%c\n", ops[i]);
	}

	free(sequence);
	free(ops);
	free(S);
	return 0;
}
